package titan;
import titan.ODESolver;
import titan.ODEFunction;
import titan.State;
import titan.PlanetReader;
import titan.Planet;

import java.util.List;
import java.util.ArrayList;

public class TitanTest {
	public static void main(String[] args) {
		ODESolver solver = new ODESolver();
		ODEFunction function = new ODEFunction();
		PlanetReader planetReader = new PlanetReader();
		List<Planet> planets = null;

		planetReader.read();
		planets = planetReader.getPlanets();
		State y0 = new State(planets);
		double[] t = new double[3];
		t[0] = 0;
		t[1] = 3000;
		t[2] = 6000;
		StateInterface[] states = solver.solve(function, y0, t);
	}
}