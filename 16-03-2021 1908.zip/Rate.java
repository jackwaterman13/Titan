package titan;
import titan.RateInterface;
import titan.Vector3dInterface;
import java.util.ArrayList;

public class Rate implements RateInterface {
	public ArrayList<Vector3dInterface> positionROCs = null; // A list to contain all position rate-of-changes
	public ArrayList<Vector3dInterface> velocityROCs = null; // A list to contain all velocity rate-of-changes

	public Rate(){ } // Empty constructor
	public Rate(ArrayList<Vector3dInterface> positionRates){ setPositionRates(positionRates); } // Constructor where we set the position ROCs
	public Rate(ArrayList<Vector3dInterface> positionRates, ArrayList<Vector3dInterface> velocityRates){ setVelocityRates(velocityRates); } // Constructor where we set both the position and velocity ROCs
	public void setPositionRates(ArrayList<Vector3dInterface> positionRates){ positionROCs = positionRates; } // Method to set the position ROCs
	public void setVelocityRates(ArrayList<Vector3dInterface> velocityRates){ velocityROCs = velocityRates; } // Method to set the velocity ROCs
	public ArrayList<Vector3dInterface> getPositionChangeRates(){ return positionROCs; } // Method to get the position ROCs
	public ArrayList<Vector3dInterface> getVelocityChangeRates(){ return velocityROCs; } // Method to get the velocity ROCs
}