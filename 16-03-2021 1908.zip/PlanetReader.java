package titan;

import titan.Vector3dInterface; 
import titan.Planet;

import java.io.File;
import java.lang.Math;
import java.util.Scanner;
import java.util.List;
import java.util.LinkedList;

public class PlanetReader{
	private List<Planet> planets = null;
	public String fileLocation = "./solar_system_data-2020_04_01.txt";
	public PlanetReader(){ }
	public PlanetReader(String fileLocation2Use){ fileLocation = fileLocation2Use; }
	public List<Planet> getPlanets(){ return planets; }
	public void setLocation(String fileLocation2Use){ fileLocation = fileLocation2Use; }

	public void read() {
		System.out.println("I am reading planets!");
		planets = new LinkedList<Planet>();
		try{ 
			File f = new File(fileLocation);
			if (!f.exists()){ System.out.println("File at specified location does not exist! | Location: " + fileLocation); return; }			
			Scanner reader  = new Scanner(f);
			while(reader.hasNextLine()){
				String line = reader.nextLine();
				if (line.length() < 1 || line.startsWith("//") || line.startsWith(" ")){ continue; }
				String planetName = line.substring(0, line.indexOf(":"));
				
				String massValue = "";
				
				String xPosition = "";
				String yPosition = "";
				String zPosition = "";
				
				String xVelocity = "";
				String yVelocity = "";
				String zVelocity = "";

				String massLabel = "mass=";
				String xPosLabel = "x=";
				String yPosLabel = "y=";
				String zPosLabel = "z=";

				String xVelLabel = "vx=";
				String yVelLabel = "vy=";
				String zVelLabel = "vz=";

				int massIndex = line.indexOf(massLabel);
				
				int xPosIndex = line.indexOf(xPosLabel);
				int yPosIndex = line.indexOf(yPosLabel);
				int zPosIndex = line.indexOf(zPosLabel);

				int xVelIndex = line.indexOf(xVelLabel);
				int yVelIndex = line.indexOf(yVelLabel);
				int zVelIndex = line.indexOf(zVelLabel);

				/* 
					Note: In case (which should not occur at all, but am too lazy to revisit the code if it happens) something happens to the text file 
					where the comma after each variable value is lost, then we check for the empty space between them.
				*/
				char[] charInLine = line.toCharArray();
				for(int i = massIndex + massLabel.length() + 1; i < xPosIndex; i++){
					if (charInLine[i] == ',' || charInLine[i] == ' '){ break; } 
					massValue += String.valueOf(charInLine[i]);
				}	

				for(int i = xPosIndex + xPosLabel.length() +1; i < yPosIndex; i++){
					if (charInLine[i] == ',' || charInLine[i] == ' '){ break; }
					xPosition += String.valueOf(charInLine[i]);
				}

				for(int i = yPosIndex + yPosLabel.length() + 1; i < zPosIndex; i++){
					if (charInLine[i] == ',' || charInLine[i] == ' '){ break; }
					yPosition += String.valueOf(charInLine[i]);
				}

				for(int i = zPosIndex + zPosLabel.length() + 1; i < xVelIndex; i++){
					if (charInLine[i] == ',' || charInLine[i] == ' '){ break; }
					zPosition += String.valueOf(charInLine[i]);
				}

				for(int i = xVelIndex + xVelLabel.length() + 1; i < yVelIndex; i++){
					if (charInLine[i] == ',' || charInLine[i] == ' '){ break; }
					xVelocity += String.valueOf(charInLine[i]);
				}

				for(int i = yVelIndex + yVelLabel.length() + 1; i < zVelIndex; i++){
					if (charInLine[i] == ',' || charInLine[i] == ' '){ break; }
					yVelocity += String.valueOf(charInLine[i]);
				}

				for(int i = zVelIndex + zVelLabel.length() + 1; i < line.length(); i++){
					if (charInLine[i] == ',' || charInLine[i] == ' '){ break; }
					zVelocity += String.valueOf(charInLine[i]);
				}

				/* Print statements to check the string values */
				// System.out.println("Currently reading planet: " + planetName);
				// System.out.println(planetName + "'s mass: " + massValue);
				// System.out.println(planetName + "'s x pos: " + xPosition);
				// System.out.println(planetName + "'s y pos: " + yPosition);
				// System.out.println(planetName + "'s z pos: " + zPosition);
				// System.out.println(planetName + "'s x vel: " + xVelocity);
				// System.out.println(planetName + "'s y vel: " + yVelocity);
				// System.out.println(planetName + "'s z vel: " + zVelocity);
				// System.out.print("\n");
				
				//Neptune: { mass=1.02413e26,   x= 4.382692942729203e+12,  y=-9.093501655486243e+11,  z=-8.227728929479486e+10,  vx= 1.068410720964204e+03, vy= 5.354959501569486e+03, vz=-1.343918199987533e+02 }
				String base = massValue.substring(0, massValue.indexOf("e") - 1);
				String e = massValue.substring(massValue.indexOf("e") + 1, massValue.length() - 1);
				double mass = Double.valueOf(base) * Math.pow(10, Double.valueOf(e));
				
				base = xPosition.substring(0, xPosition.indexOf("e") - 1);
				e = xPosition.substring(xPosition.indexOf("+") + 1, xPosition.length() - 1);
				double x = Double.valueOf(base) * Math.pow(10, Double.valueOf(e));

				base = yPosition.substring(0, yPosition.indexOf("e") - 1);
				e = yPosition.substring(yPosition.indexOf("+") + 1, yPosition.length() - 1);
				double y = Double.valueOf(base) * Math.pow(10, Double.valueOf(e));

				base = zPosition.substring(0, zPosition.indexOf("e") - 1);
				e = zPosition.substring(zPosition.indexOf("+") + 1, zPosition.length() - 1);
				double z = Double.valueOf(base) * Math.pow(10, Double.valueOf(e));

				base = xVelocity.substring(0, xVelocity.indexOf("e") - 1);
				e = xVelocity.substring(xVelocity.indexOf("+") + 1, xVelocity.length() - 1);
				double vx = Double.valueOf(base) * Math.pow(10, Double.valueOf(e));

				base = yVelocity.substring(0, yVelocity.indexOf("e") - 1);
				e = yVelocity.substring(yVelocity.indexOf("+") + 1,yVelocity.length() - 1);
				double vy = Double.valueOf(base) * Math.pow(10, Double.valueOf(e));

				base = zVelocity.substring(0, zVelocity.indexOf("e") - 1);
				e = zVelocity.substring(zVelocity.indexOf("+") + 1, zVelocity.length() - 1);
				double vz = Double.valueOf(base) * Math.pow(10, Double.valueOf(e));

				Planet p = new Planet(planetName, x, y, z, mass);
				p.setVelocity(vx, vy, vz);
				planets.add(p);

				/* Print statements to check the double values */
				// System.out.println("Currently reading planet: " + planetName);
				// System.out.println(planetName + "'s mass: " + Double.toString(mass));
				// System.out.println(planetName + "'s position: " + position.toString());
				// System.out.println(planetName + "'s velocity: " + velocity.toString());
				// System.out.print("\n");
			}
		}
		catch(Exception e){ System.out.println(e); }
	}
}