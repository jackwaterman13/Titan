package titan;
import titan.Vector3dInterface;

public class Probe
{
	private String name; // Name of the probe
	private Vector3dInterface velocity; // The current velocity of the probe
    private Vector3dInterface position; // the current position of the probe
    private Vector3dInterface gravity; // The current gravity acted upon the probe
    private double mass = 15000;  // The mass of the prob in Kg


    //Constructors
    public Probe(String name)
    {
    	this.name = name; 
    }

    public Probe(String name, double mass)
    {
    	this.name = name; 
    	this.mass = mass; 
    }

    public Probe(String name, Vector3dInterface velocity, Vector3dInterface position, Vector3dInterface gravity)
    {
    	this.name = name;  
    	this.velocity = velocity;
    	this.position = position;
    	this.gravity = gravity;
    }


    public Probe(String name, double x, double y, double z) {
		this.name = name;
		position = new Vector3d(x, y, z);
	}

	public Probe(String name, double x, double y, double z, double mass) {
		this.name = name;
		this.mass = mass;
		position = new Vector3d(x, y, z);
	}




    // Encapsulation Setters and Getters
    public void setName(String n)
    {
    	 name = n;
    }

    public void setVelocity(double vx, double vy, double vz)
    {
        velocity = new Vector3d(vx, vy, vz);
    }

    public void setVelocity(Vector3dInterface vel)
    {
    	velocity = vel;
    }

    public void setPosition(double x, double y, double z)
    {
    	position = new Vector3d(x,y,z);
    }

    public void setPosition(Vector3dInterface pos)
    {
    	position = pos;
    }

    public void setGravity(Vector3dInterface g)
    {
    	gravity = g;
    }

    public String getName()
    {
    	return name;
    }

    public double getMass()
    {
    	return mass;
    }


     public Vector3dInterface getVelocity()
    {
        return velocity;
    }

     public Vector3dInterface getPosition()
    {
        return position;
    }
     public Vector3dInterface getGravity()
     { 
     	return gravity; 
     }

    // Coordinates of the position
    public double getX()
    {
    	return position.getX();
    }
    public double getY()
    {
    	return position.getY();
    }
    public double getZ()
    {
    	return position.getZ();
    }

    // Coordinates of the velocity
    public double getVelocityX()
    {
    	return velocity.getX();
    }
    public double getVelocityY()
    {
    	return velocity.getY();
    }
    public double getVelocityZ()
    {
    	return velocity.getZ();
    }



     /**
     @return The coordinates of the current position of the probe at time t
     */

    public String toString() {
		String coordinates = "Probe + " + name + " | Position: " + position.toString();
		return coordinates;
	}


    /**
     @return The coordinates of the current velocity of the probe at time t
     */
	public String VelocitytoString() {
		String coordinates = "Probe + " + name + " | Velocity: " + velocity.toString();
		return coordinates;
	}

    /**
     @param Object of type Probe
     @return A boolean stating if both probes are the same. This method will return false if the other probe 
     * is at a different position.
     */
	public boolean equals(Probe probe2Compare)
	{
		// Compare the position
		if(getX() == probe2Compare.getX() &&  getY() == probe2Compare.getY() && getZ() == probe2Compare.getZ())
		{   
			// Compare the mass
			if(mass == probe2Compare.getMass())
			{
				//Compare the name
				if(name == probe2Compare.getName())
				{
					return true;
				} 
				else{ return false;}
			}
			else{return false;}
		}
		else{return false;}
	}


}
