package titan;

import titan.StateInterface;
import titan.Vector3dInterface;

import java.util.List;
import java.util.ArrayList;

public class State implements StateInterface{
	List<Planet> planets = null; // List to keep track of all planets and their data (such as position, velocity, mass)
	Probe probe = null; // For future usage

	public State(){ } // Empty constructor
	public State(List<Planet> planets){ this.planets = planets; } // Constructor that sets planets
	public State(List<Planet> planets, Probe probe){ this.planets = planets; this.probe = probe; } // Constructor that sets planets and probe

 	public List<Planet> getPlanets(){ return planets; } // Method to get planets
	public Probe getProbe(){ return probe; } // Method to get the probe

	public StateInterface addMul(double step, RateInterface rate){

		/*To do: Get rate of change from rate
		 *		 Multiply step with the rate-of-change to get a scaled vector?
		 *		 Then add this vector on the positioning of the planets.
		 *		 Add it as well on the acceleration? Prob yes
		 *       return new stateinterface containing the new states of all planets (& the probe)
		 */

		Rate roc = (Rate) rate; // Typecast the given RateInterface object to our rate class
		List<Planet> clones = new ArrayList<Planet>(); // Create an empty list to store clones of our planets | This is needed to avoid overriding initial-previous values for the trajectory tracking
		ArrayList<Vector3dInterface> positionROCs = roc.getPositionChangeRates(); // Get the position rate-of-changes from the Rate object
		ArrayList<Vector3dInterface> velocityROCS = roc.getVelocityChangeRates(); // Get the velocity rate-of-changes from the Rate object
		for(int i = 0; i < planets.size(); i++){ // Loop for every planet, where
			Planet p = planets.get(i); // You get the planet
			Vector3dInterface posROC = positionROCs.get(i); // Get the respective position rate-of-change
			Vector3dInterface velROC = velocityROCS.get(i); // Get the respective velocity rate-of-change
			posROC = posROC.mul(step); // Scale the position rate-of-change with the given step (size)
			velROC = velROC.mul(step); // Scale the velocity rate-of-change with the given step (size)
			Planet copy = p.getClone(); // Clone the data of the planet
			copy.updatePosition(posROC); // Update the position of the clone with the position rate-of-change
			copy.updateVelocity(velROC); // Update the velocity of the clone with the velocity rate-of-change
			clones.add(copy); // Add the clone to the clones list
		}

		return (StateInterface) new State(clones); // Create a new State object with the clones and typecast it to the StateInterface object to return it
	}

    public String toString(){ 
    	String s = "";
    	for(int i = 0; i < planets.size(); i++){
    		Planet p = planets.get(i);
    		s += p.toString();
    	}
    	return s;
    }
}