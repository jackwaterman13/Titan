package titan;
import titan.ODEFunctionInterface;
import titan.ODESolverInterface;

import titan.RateInterface;
import titan.StateInterface;

import titan.Rate;
import titan.State;

import java.util.ArrayList;
public class ODESolver implements ODESolverInterface{
	/* From the interface:
     * Solve the differential equation by taking multiple steps.
     *
     * @param   f       the function defining the differential equation dy/dt=f(t,y)
     * @param   y0      the starting state
     * @param   ts      the times at which the states should be output, with ts[0] being the initial time
     * @return  an array of size ts.length with all intermediate states along the path
     */
    public StateInterface[] solve(ODEFunctionInterface f, StateInterface y0, double[] ts){
    	ArrayList<StateInterface> states = new ArrayList<StateInterface>(); // A list to contain the states at the different time frames in the double[]
    	for(int i = 0; i < ts.length; i++){ // Loop so we can acces each time frame
    		RateInterface rInt = f.call(ts[i], y0); // Call the call method from the function passed into solve and catch its return value
    		Rate roc = (Rate) rInt; // Typecast the RateInterface to our Rate object

    		/* To-do: 	Get the rate-of-change for position and velocity for each planet (and the probe).
			 * 			Use the rate-of-change to determine the new position and velocity
			 * 			Save each planet's new positions and velocities (as a collection named state) and add it to the list
    		 */
    	}
    	StateInterface[] arr = new StateInterface[states.size()]; // Construct an empty array with the size of the list we made earlier
    	for(int i = 0; i < states.size(); i++){ arr[i] = states.get(i); } // Add the elements from the list to the array
    	return arr;
    }

    /* From the interface:
     * Solve the differential equation by taking multiple steps of equal size, starting at time 0.
     * The final step may have a smaller size, if the step-size does not exactly divide the solution time range
     *
     * @param   f       the function defining the differential equation dy/dt=f(t,y)
     * @param   y0      the starting state
     * @param   tf      the final time
     * @param   h       the size of step to be taken
     * @return  an array of size round(tf/h)+1 including all intermediate states along the path
     */
    public StateInterface[] solve(ODEFunctionInterface f, StateInterface y0, double tf, double h){
    	ArrayList<StateInterface> states = new ArrayList<StateInterface>(); // A list to contain the states at the different time frames
    	for(int i = 0; i < (int) tf / h + 1; i++){ // Loop so we can acces each time frame.
    		Rate roc = (Rate) f.call((double) i * h, y0); // Call the call method from the function and typecast catch its return value.

    		/* To-do: 	Get the rate-of-change for position and velocity for each planet (and the probe).
			 * 			Use the rate-of-change to determine the new position and velocity
			 * 			Save each planet's new positions and velocities (as a collection named state) and add it to the list
    		 */

    	}

    	StateInterface[] arr = new StateInterface[states.size()]; // Construct an empty array with the size of the list we made earlier
    	for(int i = 0; i < states.size(); i++){ arr[i] = states.get(i); } // Add the elements from the list to the array
    	return arr; 
    }

    /* From the interface:
     * Update rule for one step.
     *
     * @param   f   the function defining the differential equation dy/dt=f(t,y)
     * @param   t   the time
     * @param   y   the state
     * @param   h   the step size
     * @return  the new state after taking one step
     */
    public StateInterface step(ODEFunctionInterface f, double t, StateInterface y, double h){
    	Rate roc = (Rate) f.call(t * h, y); // Execute the function and typecast the return value

    	/* To-do: 	Get the rate-of-change for position and velocity for each planet (and the probe).
		 * 			Use the rate-of-change to determine the new position and velocity
		 * 			Save each planet's new positions and velocities (as a collection named state) and return it
    	 */
    	StateInterface yNew = null;
    	return yNew;
    }
}