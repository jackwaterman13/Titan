package titan;
import titan.Planet;
import titan.Vector3d;

import java.util.ArrayList;
import java.util.List;
import java.lang.Math;

public class Gravitation{

    private List<Planet> planets; // List of the planets
	private final double G = 6.67408 * Math.pow(10, -11);// m3 kg-1 s-2
	private Planet sun;
	private double M;


	public Gravitation(List<Planet> planets) {

		this.planets = planets;
		sun = this.planets.get(0);
		M = sun.getMass();
		planets.remove(0);
		CartesianVector();
	}

	public ArrayList<Vector3d> CartesianVector(){

		ArrayList<Vector3d> out = new ArrayList<Vector3d>();

		double xAcc;
		double yAcc;
		double zAcc;

		double x;
		double y;
		double z;
		double r;
		double[] sum;

		for (Planet a : planets){

			x = a.getX();
			y = a.getY();
			z = a.getZ();

			r = Math.pow(x*x + y*y + z*z, -3/2);

			xAcc= -(M+a.getMass())*(G*x*r);
			yAcc= -(M+a.getMass())*(G*y*r);
			zAcc= -(M+a.getMass())*(G*z*r);

			sum = sumCartesian(a);

			xAcc += sum[0];
			yAcc += sum[1];
			zAcc += sum[2];

			out.add(new Vector3d(xAcc,yAcc,zAcc));
		}

		return out;
	}

	public double[] sumCartesian(Planet a){

		double xOutA = 0;
		double xOutB = 0;
		double yOutA = 0;
		double yOutB = 0;
		double zOutA = 0;
		double zOutB = 0;

		double[] out = new double[3];

		double r;
		double r2;
		double x;
		double y;
		double z;
		double m;

		for (Planet b : planets) {
			if (a.equals(b))
				continue;
			else {
				x = b.getX();
				y = b.getY();
				z = b.getZ();
				r = Math.pow(x*x + y*y + z*z, -3/2);
				r2 = Math.pow(a.dist(b), -3);
				m = b.getMass();

				xOutA += m*x*r;
				xOutB += G*m*(x-a.getX())*r2;

				yOutA += m*y*r;
				yOutB += G*m*(y-a.getY())*r2;

				zOutA += m*z*r;
				zOutB += G*m*(z-a.getZ())*r2;
			}
		}

		out[0] = -xOutA+xOutB;
		out[1] = -yOutA+yOutB;
		out[2] = -zOutA+zOutB;

		return out;
	}
}