package titan;

import titan.Vector3dInterface;

import java.lang.Math;

public class Vector3d implements Vector3dInterface{
	private String name;
	private double x;
	private double y;
	private double z;
	
	public Vector3d(){ }
	public Vector3d(double x2Use){ setX(x2Use); }
	public Vector3d(double x2Use, double y2Use){ setX(x2Use); setY(y2Use); }
	public Vector3d(double x2Use, double y2Use, double z2Use){ setX(x2Use); setY(y2Use); setZ(z2Use); }
	public Vector3d(String name2Use){ setName(name2Use); }
	public Vector3d(String name2Use, double x2Use){ setName(name2Use); setX(x2Use); }
	public Vector3d(String name2Use, double x2Use, double y2Use){ setName(name2Use); setX(x2Use); setY(y2Use); }
	public Vector3d(String name2Use, double x2Use, double y2Use, double z2Use){ setName(name2Use); setX(x2Use); setY(y2Use); setZ(z2Use); }

	public double getX(){ return x; }
    public void setX(double x){ this.x = x; }
    public double getY() { return y; }
    public void setY(double y){ this.y = y; }
    public double getZ(){ return z; }
    public void setZ(double z){ this.z = z; }
    public Vector3dInterface add(Vector3dInterface other){ return (Vector3dInterface) new Vector3d(x += other.getX(), y += other.getY(), z += other.getZ()); }
    public Vector3dInterface sub(Vector3dInterface other){ return (Vector3dInterface) new Vector3d(x -= other.getX(), y -= other.getY(), z -= other.getZ()); }
    public Vector3dInterface mul(double scalar){ return (Vector3dInterface) new Vector3d(x *= scalar, y *= scalar, z *= scalar); }
    public Vector3dInterface addMul(double scalar, Vector3dInterface other){ 
    	Vector3dInterface vec = this.add(other);
    	vec = this.mul(scalar);
    	return vec;
    }
    
    /*
		To normalize a vector, you need to get the euclidean distance between itself and the origin 0, then divide the distance by the number of elements in the vector.
		So, d(0, V) = sqrt ( sum of vi ) where vi defines each entry for i = 1, 2, 3
    */
    public double norm(){ 
    	double size = Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2); 
    	double length = Math.sqrt(size);
    	return (double) (length / 3); 
    }
   
    public double dist(Vector3dInterface other){ 
    	double deltaX = Math.pow((other.getX() - this.x), 2);
    	double deltaY = Math.pow((other.getY() - this.y), 2);
    	double deltaZ = Math.pow((other.getZ() - this.z), 2);
    	double d = Math.sqrt(deltaX + deltaY + deltaZ);
    	return d;
    }
    
    public String toString(){ return "(" + Double.toString(x) + ", " + Double.toString(y) + ", " + Double.toString(z) + ")"; }

	public String getName(){ return name; }
	public void setName(String name2Use){ name = name2Use; }
}