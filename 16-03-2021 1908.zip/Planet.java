package titan;
import titan.Vector3dInterface;
import titan.Vector3d;
import java.lang.Math;

public class Planet{
    
    private String name = "N/A"; // Name of the planet 
    private Vector3dInterface velocity; // Planet's velocity defined in a 3-dimensional vector
    private Vector3dInterface position; // Planet's position defined in a 3-dimensional vector
    private Vector3dInterface gravity; // May be removed later
    private double mass; // Planet's mass
    
	public Planet() { } // Empty contructor
	public Planet(String name) { this.name = name; } // Constructor that sets the planet's name
	public Planet(String name, double x, double y, double z) { // Constructor that set the planet's name and position
		this.name = name;
		position = new Vector3d(x, y, z);
	}

	public Planet(String name, double x, double y, double z, double mass) { // Constructor that set the planet's name, position and mass
		this.name = name;
		this.mass = mass;
		position = new Vector3d(x, y, z);
	}
	public Planet(String name, Vector3dInterface position, Vector3dInterface velocity, double mass) { setName(name); setPosition(position); setVelocity(velocity); setMass(mass); } // Constructor that set the planet's name, position, velocity and mass
	public Planet(double x, double y, double z) { position = new Vector3d(x, y, z); } // Constructor that set the planet's position
	public Planet(double x, double y, double z, double mass) { setMass(mass); position = new Vector3d(x, y, z); } // Constructor that set the planet's position and mass

	public Planet getClone(){ return new Planet(name, position, velocity, mass); } 
	public String getName() { return name; }

	public void setName(String name) { this.name = name; }
    public void setX(double x){ position.setX(x); }
    public void setY(double y){ position.setY(y); }
	public void setZ(double z) { position.setZ(z); }
	public void setMass(double mass) { this.mass = mass; }
	public void setPosition(Vector3dInterface p){ position = p;}
	public void setGravity(Vector3dInterface g){ gravity = g; }
	public void setVelocity(double vx, double vy, double vz) { velocity = new Vector3d(vx, vy, vz); }
	public void setVelocity(Vector3dInterface v){ velocity = v; }
	public void updateVelocity(double vx, double vy, double vz) { velocity.add(new Vector3d(vx, vy, vz)); }
	public void updateVelocity(Vector3dInterface v){ velocity.add(v); }
	public void updatePosition(Vector3dInterface v){ position.add(v); }

	public double getX(){ return position.getX(); }
	public double getY(){ return position.getY(); }
	public double getZ(){ return position.getZ(); }
	public double getMass() { return mass; }
	public double getVelocityX() { return velocity.getX(); }
	public double getVelocityY() { return velocity.getY(); }
	public double getVelocityZ() { return velocity.getZ(); }

	public double dist(Planet other){ return position.dist(other.getPosition()); }
	
	public Vector3dInterface getPosition(){ return position; }
	public Vector3dInterface getVelocity(){ return velocity; }
    public Vector3dInterface getGravity(){ return gravity; }

	public String toString() {
		String coordinates = "Planet + " + name + " | Position: " + position.toString() + " ";
		return coordinates;
	}

	public String velToString() {
		String coordinates = "Planet + " + name + " | Velocity: " + velocity.toString() + " ";
		return coordinates;
	}

	public boolean equals(Planet planet2Compare) {
		if (name != "N/A" && planet2Compare.getName() != "N/A") {
			if (name.equals(planet2Compare.getName())) {
				return true;
			} else {
				return false;
			}
		}
		else {
			if (mass == planet2Compare.getMass() && position.getX() == planet2Compare.getX() && position.getY() == planet2Compare.getY() && position.getZ() == planet2Compare.getZ()) {
				return true;
			}
			else {
				return false;
			}
		}
	}
}