package titan;
import titan.ODEFunctionInterface;
import titan.Planet;
import titan.Probe;
import titan.State;
import titan.Gravitation;
import titan.Vector3d;
import titan.Vector3dInterface;

import java.util.List;
import java.util.ArrayList;
public class ODEFunction implements ODEFunctionInterface{

  	/* Summary: y defines a state of the universe concerning the positions and velocities of the planets.
     *          For a single planet y(t) can be written as (x(t), v(t)). So y = (x, v)
     *          In order to figure out how the planet will have changed after x amount of time, we should calculate the
     *          the average rate-of-change with the derative of state y over time t
     *          Which brings us to the given derative and function: dy/dt = f(t, y) from section 3
     *          t can be substituted with dy[0]/dt = y[1]
     *          y can be substituted for dy[1]/dt = y[2] = (v(t), a(t))
     *          then this f(t, y) would be f(t, y) = (y[1], y[2]) =((x(t), v1(t)), (v2(t), a(t))) = dy/dt
     *
     * Note:    The only things that can change in our context is the position and velocity of the planet.
     *          If we break it down in some more building blocks, then the derative dy/dt = f(t, y) implies
     *          given a certain amount of time the position will change by the velocity that is paired to the position (See the 1st bit of the substitution)  
     *          and the velocity will change by the acceleration that is paired to the velocity (See the 2nd bit of the substitution)
     *
     *          Or it's the velocity in the 2nd bit that changes the position in the 1 bit and the acceleration in the 2nd bit that changes the velocity in the 1st bit.
     *          Either way, there should be no differences, because the velocity in the 1st and 2nd bit should be equal ? :D
     *          
     *          1st bit of the substitution is (x, v). In here (x denotes its current position, v denotes the velocity that will change the position)
     *          2nd bit of the substitution is (v, a). In here (v denotes its current velocity (which is the same as the velocity from before?), a denotes the acceleration that will change the velocity)    
     */

    public RateInterface call(double t, StateInterface y){
    	
    	State s = (State) y; // Type casting the StateInterface to our State class
        Probe probe = s.getProbe(); // For future usage...
    	List<Planet> planets = s.getPlanets(); // Getting the planets
        ArrayList<Vector3dInterface> positionROCs = new ArrayList<Vector3dInterface>(); // Creating an arraylist to keep track of all position rate-of-changes
        ArrayList<Vector3dInterface> velocityROCs = new ArrayList<Vector3dInterface>(); // Creating an arraylist to keep track of all velocity rate-of-changes

        for(int i = 0; i < planets.size(); i++){
            Planet p = planets.get(i);

            /* To-do:   Calculate the (average) rate-of-change for the position and velocity for each planet
             *          The rate-of-change calculation consists of:
             *          - Calculating the average distance travelled over time of a planet. This is the position rate-of-change
             *          - Calculating the average acceleration over time of a planet. This is the velocity rate-of-change
             *          Save the calculation to their respective lists
             */
        }
        Rate r = new Rate(positionROCs, velocityROCs); // Construct a new Rate object to contain our position and velocity rate-of-changes.
    	return (RateInterface) r; // Return it by typecasting to the RateInterface structure
    }
}