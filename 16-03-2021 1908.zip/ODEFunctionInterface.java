/*
 * @author Pieter Collins, Christof Seiler, Katerina Stankova, Nico Roos, Katharina Schueller
 * @version 0.99.0
 *
 * This interface serves as the API for students in phase 1.
 */

package titan;

import titan.Vector3dInterface;

public interface ODEFunctionInterface {

    /*
     * This is an interface for the function f that represents the
     * differential equation ý = dy/dt = f(t,y).
     * You need to implement this function to represent to the laws of physics.
     *
     * For example, consider the differential equation
     *  dy[0]/dt = y[1];  dy[1]/dt=cos(t)-sin(y[0])
     * Then this function would be
     *   f(t,y) = (y[1],cos(t)-sin(y[0])).
     * 
     * @param   t   the time at which to evaluate the function
     * @param   y   the state at which to evaluate the function
     * @return  The average rate-of-change over the time-step. Has dimensions of [state]/[time]. 
     */

    /* Summary: y defines a state of the universe concerning the positions and velocities of the planets.
     *          For a single planet y(t) can be written as (x(t), v(t)). So y = (x, v)
     *          In order to figure out how the planet will have changed after x amount of time, we should calculate the
     *          the average rate-of-change with the derative of state y over time t
     *          Which brings us to the given derative and function: dy/dt = f(t, y) from section 3
     *          t can be substituted with dy[0]/dt = y[1]
     *          y can be substituted for dy[1]/dt = y[2] = (v(t), a(t))
     *          then this f(t, y) would be f(t, y) = (y[1], y[2]) =((x(t), v(t)), (v(t), a(t))) = dy/dt
     *
     * Note:    The only things that can change in our context is the position and velocity of the planet.
     *          If we break it down in some more building blocks, then the derative dy/dt = f(t, y) implies
     *          given a certain amount of time the position will change by the velocity that is paired to the position (See the 1st bit of the substitution)  
     *          and the velocity will change by the acceleration that is paired to the velocity (See the 2nd bit of the substitution)
     *          
     *          1st bit of the substitution is (x, v). In here (x denotes its current position, v denotes the velocity that will change the position)
     *          2nd bit of the substitution is (v, a). In here (v denotes its current velocity (which is the same as the velocity from before?), a denotes the acceleration that will change the velocity)    
     */

    public RateInterface call(double t, StateInterface y);
}